<?php

namespace Drupal\todo\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Render\Element\Date;

class TodoForm extends FormBase
{

  public function getFormId()
  {
    return 'todo_form';
  }


  public function buildForm(array $form, FormStateInterface $form_state)
  {

    $conn = Database::getConnection();

    $record = array();
    if (isset($_GET['num'])) {
      $query = $conn->select('todo', 'm')
        ->condition('sno', $_GET['num'])
        ->fields('m');
      $record = $query->execute()->fetchAssoc();
     //echo "<pre>";print_r('hloo');die;
    }


    $form['name'] = array(
      '#type' => 'textfield',
      '#title' => t('name:'),
      '#required' => TRUE,
      //'#default_values' => array(array('sno')),
      '#default_value' => (isset($record['name']) && $_GET['num']) ? $record['name'] : '',
    );
    $form['email'] = array(
      '#type' => 'email',
      '#title' => t('email:'),
      '#default_value' => (isset($record['email']) && $_GET['num']) ? $record['email'] : '',
    );

    $form['age'] = array(
      '#type' => 'textfield',
      '#title' => t('age'),
      '#required' => TRUE,
      '#default_value' => (isset($record['age']) && $_GET['num']) ? $record['age'] : '',
    );


    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'save',
      //'#value' => t('Submit'),
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    $name = $form_state->getValue('name');
    if (preg_match('/[^A-Za-z]/', $name)) {
      $form_state->setErrorByName('name', $this->t('your name must in characters without space'));
    }
    if (!intval($form_state->getValue('age'))) {
      $form_state->setErrorByName('age', $this->t('Age needs to be a number'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state)
  {

    $field = $form_state->getValues();
    $name = $field['name'];
    //echo "$name";
    $email = $field['email'];
    $age = $field['age'];
    if (isset($_GET['num'])) {
      $field = array(
        'name' => $name,
        'email' => $email,
        'age' => $age,
      );
      $query = \Drupal::database();
      $query->update('todo')
        ->fields($field)
        ->condition('sno', $_GET['num'])
        ->execute();
      drupal_set_message("successfully updated");
    } else {
      $field = array(
        'name' => $name,
        'email' => $email,
        'age' => $age,
      );
      $query = \Drupal::database();
      $query->insert('todo')
        ->fields(['name','email','age','created_at'])
        ->values([
          $name,
          $email,
          $age,
          Date('Y-m-d'),
        ])
        ->execute();
      drupal_set_message("successfully saved");
    }
  }
}
