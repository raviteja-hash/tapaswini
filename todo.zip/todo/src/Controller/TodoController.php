<?php

namespace Drupal\todo\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database;
use Drupal\Core\Url;


class TodoController extends ControllerBase {

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */


  public function getContent()
  {
    $connection = \Drupal::database();
    $query = $connection->select('todo', 'td')
      ->fields('td', ['sno', 'name', 'email', 'age'] );
    $results = $query->execute()->fetchAll();


    if ($cache = \Drupal::cache()->get('teja')) {


      $cached_data = \Drupal::cache()->get('teja')->data;
      $form['text']['#markup'] = t('cached Data....');
      $header = [
        'sno' => t('Sno'),
        'name' => t('Username'),
        'email' => t('Email'),
        'age'  => t('Age'),
        'Edit' => t('Edit'),

      ];

      // Initialize an empty array
      $output = array();
      foreach ($cached_data as $result) {

        $edit   = Url::fromUserInput('/todo/add?num='.$result->sno);



        $output[$result->sno] = [
          'Sno' => $result->sno,
          'name' => $result->name,
          'email' => $result->email,
          'age' => $result->age,
          \Drupal::l('Edit', $edit),

        ];
      }
      $form['table'] = [
        '#type' => 'table',
        '#header' => $header,
        '#rows' => $output,
        '#empty' => t('No users found'),
      ];

      return $form;


    }else {

      \Drupal::cache()->set('teja', $results);
      $form['text']['#markup'] = t('<h1>cleared caching</h1>');
      $build = [
        '#markup' => $this->t('cached cleared!'),
      ];

      $header = [
        'sno' => t('Sno'),
        'name' => t('Username'),
        'email' => t('Email'),
        'age'  => t('Age'),
        'Edit' => t('Edit'),
      ];

      // Initialize an empty array
      $output = array();
      foreach ($results as $result) {

        $edit   = Url::fromUserInput('/todo/add?num='.$result->sno);



        $output[$result->sno] = [
          'Sno' => $result->sno,
          'name' => $result->name,
          'email' => $result->email,
          'age' => $result->age,
          \Drupal::l('Edit', $edit),

        ];
      }
      $form['table'] = [
        '#type' => 'table',
        '#header' => $header,
        '#rows' => $output,
        '#empty' => t('No users found'),
      ];

      return $form;
    }

    /*$connection = \Drupal::database();
    $query = $connection->select('todo', 'td')
      ->fields('td', ['sno', 'name', 'email', 'age'] );
    $results = $query->execute()->fetchAll();

    $header = [
      'sno' => t('Sno'),
      'name' => t('Username'),
      'email' => t('Email'),
      'age'  => t('Age'),
      'Edit' => t('Edit'),
    ];

    // Initialize an empty array
    $output = array();
    foreach ($results as $result) {
//echo "<pre>";
//print_r($result);die;

      $edit   = Url::fromUserInput('/todo/add?num='.$result->sno);



      $output[$result->sno] = [
        'Sno' => $result->sno,
        'name' => $result->name,
        'email' => $result->email,
        'age' => $result->age,
        \Drupal::l('Edit', $edit),
        \Drupal::l('Delete', $delete),

      ];
    }
    $form['table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $output,
      '#empty' => t('No users found'),
    ];

    return $form;
*/




  }


}
