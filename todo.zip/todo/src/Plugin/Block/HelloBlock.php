<?php
namespace Drupal\todo\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Provides a 'Hello' Block.
 *
 * @Block(
 *   id = "hello_block",
 *   admin_label = @Translation("To_Do block"),
 *   category = @Translation("Hello World"),
 * )
 */
class HelloBlock extends BlockBase implements BlockPluginInterface {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $today = date("Y-m-d");
   //$current_date = '2019-07-30';
    $results = \Drupal::database()->select('todo', 'u')
      ->condition('u.created_at',$today, '=')
      ->fields('u', ['sno', 'name', 'email', 'age'])
      ->execute()->fetchAll();
    $header = [
      'sno' => t('Sno'),
      'name' => t('Username'),
      'email' => t('Email'),
      'age'  => t('Age'),
      'Edit' => t('Edit'),

    ];

    // Initialize an empty array
    $output = array();
    foreach ($results as $result) {
//echo "<pre>";
//print_r($result);die;
      $edit   = Url::fromUserInput('/todo/add?num='.$result->sno);



      $output[$result->sno] = [
        'Sno' => $result->sno,
        'name' => $result->name,
        'email' => $result->email,
        'age' => $result->age,
        \Drupal::l('Edit', $edit),

      ];
    }
    $form['table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $output,
      '#empty' => t('No users found'),
    ];

    return $form;

  }
  public function blockForm($form, FormStateInterface $form_state) {


    $connection = \Drupal::database();
    $query = $connection->query("SELECT *  FROM {todo}");
    $result = $query->fetchAll();


    $form = parent::blockForm($form, $form_state);

    $config = $this->getConfiguration();

  }
}
